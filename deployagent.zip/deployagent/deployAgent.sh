#!/usr/bin/bash
function getConfigProperties {
    
    # Load proxy and Controller settings
    configProperties=$(echo $PWD"/conf/properties.xml")
    controllerHostProd=$(awk '/<prod>/,/<\/prod>/' $configProperties | perl -n -e'/\<host\>(.*)\<\/host\>/ && print $1')
    controllerPortProd=$(awk '/<prod>/,/<\/prod>/' $configProperties | perl -n -e'/\<port\>(.*)\<\/port\>/ && print $1')
    controllerProtocolProd=$(awk '/<prod>/,/<\/prod>/' $configProperties | perl -n -e'/\<protocol\>(.*)\<\/protocol\>/ && print $1')
    controllerAccountProd=$(awk '/<prod>/,/<\/prod>/' $configProperties | perl -n -e'/\<account\>(.*)\<\/account\>/ && print $1')
    controllerAccessKeyProd=$(awk '/<prod>/,/<\/prod>/' $configProperties | perl -n -e'/\<accesskey\>(.*)\<\/accesskey\>/ && print $1')
    controllerHostNonprod=$(awk '/<nonprod>/,/<\/nonprod>/' $configProperties | perl -n -e'/\<host\>(.*)\<\/host\>/ && print $1')
    controllerPortNonprod=$(awk '/<nonprod>/,/<\/nonprod>/' $configProperties | perl -n -e'/\<port\>(\d+)\<\/port\>/ && print $1')
    controllerProtocolNonprod=$(awk '/<nonprod>/,/<\/prnonprodod>/' $configProperties | perl -n -e'/\<protocol\>(.*)\<\/protocol\>/ && print $1')
    controllerAccountNonprod=$(awk '/<nonprod>/,/<\/nonprod>/' $configProperties | perl -n -e'/\<account\>(.*)\<\/account\>/ && print $1')
    controllerAccessKeyNonprod=$(awk '/<nonprod>/,/<\/nonprod>/' $configProperties | perl -n -e'/\<accesskey\>(.*)\<\/accesskey\>/ && print $1')
    proxyHost=$(awk '/<controller-proxy-info>/,/<\/controller-proxy-info>/' $configProperties | perl -n -e'/\<host\>(.*)\<\/host\>/ && print $1')
    proxyPort=$(awk '/<controller-proxy-info>/,/<\/controller-proxy-info>/' $configProperties | perl -n -e'/\<port\>(\d+)\<\/port\>/ && print $1')
    proxyProtocol=$(awk '/<controller-proxy-info>/,/<\/controller-proxy-info>/' $configProperties | perl -n -e'/\<protocol\>(.*)\<\/protocol\>/ && print $1')
    proxyEnabled=$(awk '/<controller-proxy-info>/,/<\/controller-proxy-info>/' $configProperties | perl -n -e'/\<enabled\>(.*)\<\/enabled\>/ && print $1')
    FABProxy="$proxyHost:$proxyPort"
    ApiAppsUri=$(awk '/<controller-api-info>/,/<\/controller-api-info>/' $configProperties | perl -n -e'/\<api-app\>(.*)\<\/api-app\>/ && print $1')
    ApiTokProd=$(awk '/<controller-api-info>/,/<\/controller-api-info>/' $configProperties | perl -n -e'/\<api-token-prod\>(.*)\<\/api-token-prod\>/ && print $1')
    ApiTokNonprod=$(awk '/<controller-api-info>/,/<\/controller-api-info>/' $configProperties | perl -n -e'/\<api-token-dev\>(.*)\<\/api-token-dev\>/ && print $1')

}
function setHomeDir {

    # Prepare home directory
    echo ""
    if [[ ! -d /opt/appdynamics ]]; then
        echo $(date '+%H:%M:%S')" - Creating /opt/appdynamics."
        mkdir -p /opt/appdynamics
    else
        echo $(date '+%H:%M:%S')" - /opt/appdynamics already exists."
    fi
    home="/opt/appdynamics"
    backupDir="backup"

}
function setSAASController {
    
    # Select Controller
    echo ""
    echo "Production monitoring (yes/no)? "
    read answer
    case $answer in
        yes|y|YES|Y)
            ControllerHost=$controllerHostProd
            ControllerAccountName=$controllerAccountProd
            ControllerProtocol=$controllerProtocolProd
            ControllerPort=$controllerPortProd
            ControllerAccountName=$controllerAccountProd
            ControllerAccessKey=$controllerAccessKeyProd
            ControllerAccessToken=$ApiTokProd
            ;;
        no|n|NO|N)
            ControllerHost=$controllerHostNonprod
            ControllerAccountName=$controllerAccountNonprod
            ControllerProtocol=$controllerProtocolNonprod
            ControllerPort=$controllerPortNonprod
            ControllerAccountName=$controllerAccountNonprod
            ControllerAccessKey=$controllerAccessKeyNonprod
            ControllerAccessToken=$ApiTokNonprod
            ;;
        *)
            echo $(date '+%H:%M:%S')" - Not allowed: accepts only 'yes' or 'no'."
            exit
            ;;
    esac

}
function getSAASController {

    if [[ $proxyEnabled = "true" ]]; then
        curl -s -H "Authorization:Bearer $ControllerAccessToken" -i "$ControllerProtocol://$ControllerHost:$ControllerPort/controller$ApiAppsUri" --proxy $FABProxy > output
        sed -i 's/\r//g' output
        applist=($(cat output | grep -Po '<name>.+' | sed 's/<name>//g;s/<\/name>/ | /g'))
        httpstate=($(cat output | perl -n -e '/HTTP*.*(\d\d\d)/ && print $1'))

    elif [[ $proxyEnabled = "false" ]]; then
        curl -s -H "Authorization:Bearer $ControllerAccessToken" -i "$ControllerProtocol://$ControllerHost:$ControllerPort/controller$ApiAppsUri" > output
        sed -i 's/\r//g' output
        applist=($(cat output | grep -Po '<name>.+' | sed 's/<name>//g;s/<\/name>/ | /g'))
        httpstate=($(cat output | perl -n -e '/HTTP*.*(\d\d\d)/ && print $1'))
    fi
    rm -rf output

    if [[ $httpstate -eq 200 || $httpstate -eq 200200 ]]; then
        echo ""
        echo $(date '+%H:%M:%S')" - Controller connectivity check succeeded ($httpstate)."
    else
        echo ""
        echo $(date '+%H:%M:%S')" - Could not verify connection to Controller ($httpstate)."
        exit
    fi


}
function setAppName {

    # Set the application name
    echo ""
    echo "Available AppDynamics Controller applications for $ControllerHost:"
    echo ${applist[@]}
    echo ""
    echo "AppDynamics Controller Application name: "
    read answer
    case $answer in
        *)
            ControllerApplicationName=$answer
            ;;
    esac

    for app in ${applist[@]}
    do
        if [ $ControllerApplicationName = $app ]; then
            ((Result++))
        fi
    done

    if [[ $Result -eq 1 ]]; then
        echo ""
        echo $(date '+%H:%M:%S')" - Matched results: $Result."
    elif [[ $Result -eq 0 ]]; then
        echo ""
        echo $(date '+%H:%M:%S')" - Application not part of any known list."
        exit
    fi

}
function setAppTierName {
    echo ""
    echo "Tier name: "
    read answer
    case $answer in
        *)
            appTierName=$answer
            ;;
    esac
}
function setAppNodeName {
    echo ""
    echo "Node name: "
    read answer
    case $answer in
        *)
            appNodeName=$answer
            ;;
    esac
    echo ""
}
function setJavaType {
    echo ""
    echo "Select JVM (Sun/IBM): "
    read answer
    case $answer in
        Sun)
            JavaAgentType=$answer
            var1=$(echo $PWD"/binaries/JavaInstall/Sun/")
            var2=$(ls binaries/JavaInstall/Sun/)
            JavaAgentSourceDir=$(echo $var1$var2)
            ;;
        IBM)
            JavaAgentType=$answer
            var1=$(echo $PWD"/binaries/JavaInstall/IBM/")
            var2=$(ls binaries/JavaInstall/IBM/)
            JavaAgentSourceDir=$(echo $var1$var2)
            ;;
        *)
            echo $(date '+%H:%M:%S')" - Not allowed: accepts only 'Sun' or 'IBM'."
            exit
            ;;
    esac
}
function setJavaApplication {
    echo ""
    echo "Available applications for monitoring:"
    echo "JBoss | Tomcat | WebSphereAS"
    echo ""
    echo "Application to monitor: "
    read answer
    case $answer in
        JBOSS|JBoss|jboss)
            appToMonitor="JBoss"
            ;;
        Tomcat|TOMCAT|tomcat)
            appToMonitor="Tomcat"
            ;;
        WebSphereAS|WEBSPHEREAS|websphereas)
            appToMonitor="WebSphereAS"
            ;;
        *)
            echo ""
            echo $(date '+%H:%M:%S')" - Application not part of any known list."
            exit
            ;;
    esac
    if [ $appToMonitor = "JBoss" ]; then
        echo ""
        echo "Full path to application start-up script (ex: /opt/jboss/jboss-as/bin/run.conf): "
        read answer
        case $answer in
            *)
                appStartUpScript=$answer
                ;;
        esac
        echo ""
        echo $(date '+%H:%M:%S')" - Checking if $appStartUpScript exists."
        if [[ -s ${appStartUpScript} ]]; then
            echo $(date '+%H:%M:%S')" - File exists and is of non-zero size."
        else
            echo $(date '+%H:%M:%S')" - File not found or empty."
            exit
        fi
    elif [ $appToMonitor = "Tomcat" ]; then
        echo ""
        echo "Full path to Tomcat bin directory (ex: /opt/tomcat/bin/): "
        read answer
        case $answer in
            *)
                appBinDir=$answer
                ;;
        esac
        echo ""
        echo $(date '+%H:%M:%S')" - Looking for setenv.sh in $appBinDir."
        if [[ -s $appBinDir"setenv.sh" ]]; then
            echo $(date '+%H:%M:%S')" - File exists and is of non-zero size."
        else
            echo $(date '+%H:%M:%S')" - File not found or empty."
            echo $(date '+%H:%M:%S')" - Creating "$appBinDir"setenv.sh."
            touch $appBinDir"setenv.sh"
        fi
        appStartUpScript=$appBinDir"setenv.sh"
    elif [ $appToMonitor = "WebSphereAS" ]; then
        echo ""
        echo "Full path to server.xml (ex: /opt/IBM/WebSphere/AppServer/profiles/AppSrv01/config/cells/mycell/nodes/mynode/servers/server1/server.xml): "
        read answer
        case $answer in
            *)
                WebSphereAsServerXML=$answer
                ;;
        esac
        echo ""
        echo "Full path to server.policy (ex: /opt/IBM/WebSphere/AppServer/profiles/myapp/properties/server.policy): "
        read answer
        case $answer in
            *)
                WebSphereAsPolicyFile=$answer
                ;;
        esac
        echo ""
        echo $(date '+%H:%M:%S')" - Looking for server.xml."
        if [[ -s $WebSphereAsServerXML ]]; then
            echo $(date '+%H:%M:%S')" - File exists and is of non-zero size."
            echo $(date '+%H:%M:%S')" - Checking for existing instrumentation."
            if [[ $(grep -ice "appdynamics" -ice "javaagent" -ice "dappdynamics" $WebSphereAsServerXML) -gt 0 ]]; then
                echo $(date '+%H:%M:%S')" - Instrumentation already exists. Setup will quit."
                echo $(date '+%H:%M:%S')" - Start up script should contain no instrumentation settings."
                exit
            fi
        else
            echo $(date '+%H:%M:%S')" - File not found or empty."
            exit
        fi
        echo $(date '+%H:%M:%S')" - Looking for server.policy."
        if [[ -s $WebSphereAsPolicyFile ]]; then
            echo $(date '+%H:%M:%S')" - File exists and is of non-zero size."
            echo $(date '+%H:%M:%S')" - Checking for existing configuration."
            if [[ $(grep -ice "appdynamics" -ice "javaagent" $WebSphereAsPolicyFile) -gt 0 ]]; then
                echo $(date '+%H:%M:%S')" - Configuration already exists. Setup will quit."
                echo $(date '+%H:%M:%S')" - policy file should contain no existing AppDynamics settings."
                exit
            fi
        else
            echo $(date '+%H:%M:%S')" - File not found or empty."
            exit
        fi
    else
        echo $(date '+%H:%M:%S')" - Application not part of any known list."
        exit
    fi
}
function instrJavaApplication {
    if [ $appToMonitor = "JBoss" ]; then
        echo $(date '+%H:%M:%S')" - Instrumenting $appStartUpScript."
        if [[ $(grep -ce "javaagent" $appStartUpScript) -gt 0 || $(grep -ce "appdynamics" $appStartUpScript) -gt 0 ]]; then
            echo $(date '+%H:%M:%S')" - Instrumentation already exists. Setup will quit."
            echo $(date '+%H:%M:%S')" - Start up script should contain no instrumentation settings."
            exit
        elif [[ $(grep -ce "javaagent" $appStartUpScript) -eq 0 && $(grep -ce "appdynamics" $appStartUpScript) -eq 0 ]]; then
            echo $(date '+%H:%M:%S')" - Creating backup of $appStartUpScript"
            name=$(ls $appStartUpScript | perl -n -e'/\/(\w+\.\w+)$/ && print $1')
            cp $appStartUpScript $backupDir/JavaAgent/$name"-$(date +"%Y_%m_%d_%I_%M_%S_%p")"
            echo $(date '+%H:%M:%S')" - Adding runtime parameters to $appStartUpScript."
            if [[ $proxyEnabled = "true" ]]; then
                printf "\n# AppDynamics Java Agent parameters\nJAVA_OPTS=\"\$JAVA_OPTS -javaagent:$JavaAgentInstallDir/$JavaAgentVerDir/javaagent.jar -Dappdynamics.agent.applicationName=$ControllerApplicationName -Dappdynamics.agent.tierName=$appTierName -Dappdynamics.agent.nodeName=$appNodeName -Dappdynamics.http.proxyHost=$proxyHost -Dappdynamics.http.proxyPort=$proxyPort\"" >> $appStartUpScript
            elif [[ $proxyEnabled = "false" ]]; then
                printf "\n# AppDynamics Java Agent parameters\nJAVA_OPTS=\"\$JAVA_OPTS -javaagent:$JavaAgentInstallDir/$JavaAgentVerDir/javaagent.jar -Dappdynamics.agent.applicationName=$ControllerApplicationName -Dappdynamics.agent.tierName=$appTierName -Dappdynamics.agent.nodeName=$appNodeName\"" >> $appStartUpScript                
            fi
            echo $(date '+%H:%M:%S')" - Done. Please restart your application once feasible and apply some load."
        fi
        exit
    elif [ $appToMonitor = "Tomcat" ]; then
        echo $(date '+%H:%M:%S')" - Instrumenting $appStartUpScript."
        if [[ $(grep -ce "javaagent" $appStartUpScript) -gt 0 || $(grep -ce "appdynamics" $appStartUpScript) -gt 0 ]]; then
            echo $(date '+%H:%M:%S')" - Instrumentation already exists. Setup will quit."
            echo $(date '+%H:%M:%S')" - Start up script should contain no instrumentation settings."
            exit
        elif [[ $(grep -ce "javaagent" $appStartUpScript) -eq 0 && $(grep -ce "appdynamics" $appStartUpScript) -eq 0 ]]; then
            echo $(date '+%H:%M:%S')" - Creating backup of $appStartUpScript"
            
            # X
            cp $appStartUpScript $backupDir/JavaAgent/"setenv.sh-$(date +"%Y_%m_%d_%I_%M_%S_%p")"
            
            echo $(date '+%H:%M:%S')" - Adding runtime parameters to $appStartUpScript."
            if [[ $proxyEnabled = "true" ]]; then
                printf "\n# AppDynamics Java Agent parameters\nexport CATALINA_OPTS=\"\$CATALINA_OPTS -javaagent:$JavaAgentInstallDir/$JavaAgentVerDir/javaagent.jar -Dappdynamics.agent.applicationName=$ControllerApplicationName -Dappdynamics.agent.tierName=$appTierName -Dappdynamics.agent.nodeName=$appNodeName -Dappdynamics.http.proxyHost=$proxyHost -Dappdynamics.http.proxyPort=$proxyPort\"" >> $appStartUpScript
            elif [[ $proxyEnabled = "false" ]]; then
                printf "\n# AppDynamics Java Agent parameters\nexport CATALINA_OPTS=\"\$CATALINA_OPTS -javaagent:$JavaAgentInstallDir/$JavaAgentVerDir/javaagent.jar -Dappdynamics.agent.applicationName=$ControllerApplicationName -Dappdynamics.agent.tierName=$appTierName -Dappdynamics.agent.nodeName=$appNodeName\"" >> $appStartUpScript            
            fi
            echo $(date '+%H:%M:%S')" - Done. Please restart your application once feasible and apply some load."
        fi
        exit
    elif [ $appToMonitor = "WebSphereAS" ]; then
        echo $(date '+%H:%M:%S')" - Instrumenting WebSphere Application Server."
        if [[ $(grep -ice "appdynamics" -ice "javaagent" $WebSphereAsServerXML) -gt 0 ]]; then
            echo $(date '+%H:%M:%S')" - Instrumentation already exists. Setup will quit."
            echo $(date '+%H:%M:%S')" - server.xml should contain no instrumentation settings."
        else
            echo $(date '+%H:%M:%S')" - Creating backup of server.xml"
            cp $WebSphereAsServerXML $backupDir/JavaAgent/server.xml"-$(date +"%Y_%m_%d_%I_%M_%S_%p")"
            echo $(date '+%H:%M:%S')" - Creating backup of server.policy"
            cp $WebSphereAsPolicyFile $backupDir/JavaAgent/server.policy"-$(date +"%Y_%m_%d_%I_%M_%S_%p")"
            echo $(date '+%H:%M:%S')" - Adding runtime parameters to server.xml."
            JvmArgOld=$(grep -e "genericJvmArguments" $WebSphereAsServerXML | perl -n -e'/genericJvmArguments\=\"(.*)\"/ && print $1')
            if [[ $proxyEnabled = "true" ]]; then
                JvmArgNew=$JvmArgOld" -javaagent:$JavaAgentInstallDir/$JavaAgentVerDir/javaagent.jar -Dappdynamics.agent.applicationName=$ControllerApplicationName -Dappdynamics.agent.tierName=$appTierName -Dappdynamics.agent.nodeName=$appNodeName -Dappdynamics.http.proxyHost=$proxyHost -Dappdynamics.http.proxyPort=$proxyPort"
            elif [[ $proxyEnabled = "false" ]]; then
                JvmArgNew=$JvmArgOld" -javaagent:$JavaAgentInstallDir/$JavaAgentVerDir/javaagent.jar -Dappdynamics.agent.applicationName=$ControllerApplicationName -Dappdynamics.agent.tierName=$appTierName -Dappdynamics.agent.nodeName=$appNodeName"
            fi
            sed -i 's!genericJvmArguments="'"$JvmArgOld"'"!genericJvmArguments="'"$JvmArgNew"'"!' "$WebSphereAsServerXML"        
        fi
        if [[ $(grep -ice "statisticSet=\"none\"" $WebSphereAsServerXML) -gt 0 ]]; then
            statisticSetOld=$(grep -e "statisticSet" $WebSphereAsServerXML | perl -n -e'/statisticSet\=\"(.*)\"/ && print $1')
            sed -i 's!statisticSet="'"$statisticSetOld"'"!statisticSet="basic"!' "$WebSphereAsServerXML"  
        fi
        #printf "\n// Allow AppDynamics Monitoring\ngrant codeBase\"file:$JavaAgentInstallDir/$JavaAgentVerDir/-\" {\n  permission java.security.AllPermission;\n};" >> $WebSphereAsPolicyFile
        printf "\n// Allow AppDynamics Monitoring\ngrant codeBase\"file:$JavaAgentInstallDir/-\" {\n  permission java.security.AllPermission;\n};" >> $WebSphereAsPolicyFile
        echo $(date '+%H:%M:%S')" - Done. Please restart your application once feasible and apply some load."
        exit
    else
        echo $(date '+%H:%M:%S')" - Application not part of any known list."
        exit
    fi
}
function setMachineAgent {
    
    # Check OS compatibility
    OsName=$(grep -e "^NAME=" /etc/os-release | perl -n -e'/NAME=\"(.*)\"/ && print $1')
    OsVer=$(grep -e "^VERSION_ID=" /etc/os-release | perl -n -e'/VERSION_ID=\"(.*)\"/ && print $1')
    OsArch=$(arch)
    echo $(date '+%H:%M:%S')" - Running on $OsName $OsVer ($OsArch)."
    if [[ $OsName =~ "Cent" || $OsName =~ "Red Hat" ]] && [[ $OsVer == 7 || $OsVer > 7 ]]; then
        echo $(date '+%H:%M:%S')" - OS check succeeded."
    else
        echo $(date '+%H:%M:%S')" - Unsupported OS and/or OS version."
        echo $(date '+%H:%M:%S')" - systemd runs on CentOS/RHEL 7 or later."
        exit
    fi

    # Confirm if app agent exists
    echo ""
    echo "Advanced infrastructure metrics (yes/no)? "
    read answer
    case $answer in
        yes|y|YES|Y)
            simEnabled="true"
            ;;
        no|n|NO|N)
            simEnabled="false"
            ;;
        *)
            echo $(date '+%H:%M:%S')" - Not allowed: accepts only 'yes' or 'no'."
            exit
            ;;
    esac
    echo ""
    echo "Host contains application (Java/Node.js/PHP/etc) agent (yes/no)? "
    read answer
    case $answer in
        yes|y|YES|Y)
            MachineAgentOnly="false"
            ;;
        no|n|NO|N)
            MachineAgentOnly="true"
            ;;
        *)
            echo $(date '+%H:%M:%S')" - Not allowed: accepts only 'yes' or 'no'."
            exit
            ;;
    esac
    echo ""

    # Set installation dir
    MachineAgentInstallDir=$(echo $home"/MachineAgent/")
    numOfFiles=$(ls $MachineAgentInstallDir | wc -l)
    if [[ ! -d $MachineAgentInstallDir ]] || [[ $numOfFiles -eq 0 ]]; then
        echo $(date '+%H:%M:%S')" - Using $MachineAgentInstallDir."
    else
        echo $(date '+%H:%M:%S')" - $MachineAgentInstallDir not empty."
        echo $(date '+%H:%M:%S')" - This script uses $MachineAgentInstallDir."
        exit
    fi

}
function installMA {
    
    # Verify installation package
    echo $(date '+%H:%M:%S')" - Verifying install package."
    if [[ $OsArch =~ "64" ]]; then
        binaries="binaries/MachineInstall/Linux/x64/"
    else
        binaries="binaries/MachineInstall/Linux/x86/"
    fi
    numOfFiles=$(ls $binaries | wc -l)
    if [[ $numOfFiles -ne 1 ]]; then
        echo $(date '+%H:%M:%S')" - Expected 1 file in binaries dir."
        exit
    fi
    if [ $OsArch="x86_64" ]; then
        var1=$(echo $PWD"/binaries/MachineInstall/Linux/x64/")
        var2=$(ls binaries/MachineInstall/Linux/x64/)
    else
        var1=$(echo $PWD"/binaries/MachineInstall/Linux/x86/")
        var2=$(ls binaries/MachineInstall/Linux/x86/)
    fi
    MachineAgentSource=$(echo $var1$var2)
    isZIP=$(echo $MachineAgentSource | grep -ice ".zip")
    if [[ $isZIP -eq 1 ]]; then
        echo $(date '+%H:%M:%S')" - Verified."
    else
        echo $(date '+%H:%M:%S')" - File extension could not be verified."
        exit
    fi
    
    # Unzip installation package
    echo $(date '+%H:%M:%S')" - Checking destination dir and package."
    if [[ ! -d $MachineAgentInstallDir ]]; then
        mkdir -p $MachineAgentInstallDir &>/dev/null
    fi
    if [[ -d $MachineAgentInstallDir ]]; then
        verifyOSUser "$MachineAgentSource" "$MachineAgentInstallDir"
    else
        echo $(date '+%H:%M:%S')" - Could not create $MachineAgentInstallDir."
        exit
    fi
    echo $(date '+%H:%M:%S')" - Unzip operation in progress."
    unzip -qq $MachineAgentSource -d $MachineAgentInstallDir
    
    # Verify unzipped dir
    if [[ ! -d $MachineAgentInstallDir ]]; then
        echo $(date '+%H:%M:%S')" - Not found: $MachineAgentInstallDir"
        exit
    fi
    numOfFiles=$(ls $MachineAgentInstallDir | wc -l)
    if [[ $numOfFiles -gt 0 ]]; then
        echo $(date '+%H:%M:%S')" - Unzip operation finished."
    else
        echo $(date '+%H:%M:%S')" - Failed to verify unzip destination folder."
        exit
    fi
    echo $(date '+%H:%M:%S')" - Verifying new directory."
    MachineAgentControllerXML=$(echo $MachineAgentInstallDir"conf/controller-info.xml")
    MachineAgentConfDir=$(echo $MachineAgentInstallDir"conf/")
    if [[ ! -e $MachineAgentControllerXML ]]; then
        echo $(date '+%H:%M:%S')" - Not found: $MachineAgentControllerXML."
        echo $(date '+%H:%M:%S')" - Searching for required setup files."
        MachineAgentInstallDirTemp=$(find $MachineAgentInstallDir -type f -name "machineagent.jar" | sed 's~/[^/]*$~/~')
        echo $(date '+%H:%M:%S')" - Required files available in $MachineAgentInstallDirTemp"
        echo $(date '+%H:%M:%S')" - Moving setup files to $MachineAgentInstallDir"
        mv $MachineAgentInstallDirTemp/* $MachineAgentInstallDir
        echo $(date '+%H:%M:%S')" - Setup files moved, proceeding with setup."
    else
        echo $(date '+%H:%M:%S')" - Found: $MachineAgentControllerXML."
    fi
    MachineAgentExec=$(echo $MachineAgentInstallDir"bin/machine-agent")
    if [[ ! -x $MachineAgentExec ]]; then
        echo $(date '+%H:%M:%S')" - Insufficient privileges: $MachineAgentExec"
        echo $(date '+%H:%M:%S')" - Fix file permissions before starting the agent."
        hasExecute="no"
    else
        hasExecute="yes"
    fi

    # Update controller-info.xml
    if [[ -f $MachineAgentControllerXML ]]; then
        echo $(date '+%H:%M:%S')" - Verified controller-info.xml."
    else
	echo $(date '+%H:%M:%S')" - Not found: $MachineAgentControllerXML."
	exit
    fi
    echo $(date '+%H:%M:%S')" - Updating controller-info.xml."
    MachineAgentControllerKeystorePass="changeit"        
    if [ $MachineAgentOnly = "true" ]; then
        sed -i "s|<controller-host></controller-host>|<controller-host>$ControllerHost</controller-host>|; s|<sim-enabled>false</sim-enabled>|<sim-enabled>$simEnabled</sim-enabled>|; s|<controller-port></controller-port>|<controller-port>443</controller-port>|; s|<controller-ssl-enabled>false</controller-ssl-enabled>|<controller-ssl-enabled>true</controller-ssl-enabled>|; s|<use-encrypted-credentials></use-encrypted-credentials>|<use-encrypted-credentials>false</use-encrypted-credentials>|; s|<account-name></account-name>|<account-name>$ControllerAccountName</account-name>|; s|<account-access-key></account-access-key>|<account-access-key>$ControllerAccessKey</account-access-key>|; s|</controller-info>|<application-name>$ControllerApplicationName</application-name><tier-name>$appTierName</tier-name><node-name>$appNodeName</node-name><controller-keystore-filename>cacerts.jks</controller-keystore-filename><controller-keystore-password>$MachineAgentControllerKeystorePass</controller-keystore-password></controller-info>|" $MachineAgentControllerXML
    elif [ $MachineAgentOnly = "false" ]; then
        sed -i "s|<controller-host></controller-host>|<controller-host>$ControllerHost</controller-host>|; s|<sim-enabled>false</sim-enabled>|<sim-enabled>$simEnabled</sim-enabled>|; s|<controller-port></controller-port>|<controller-port>443</controller-port>|; s|<controller-ssl-enabled>false</controller-ssl-enabled>|<controller-ssl-enabled>true</controller-ssl-enabled>|; s|<use-encrypted-credentials></use-encrypted-credentials>|<use-encrypted-credentials>false</use-encrypted-credentials>|; s|<account-name></account-name>|<account-name>$ControllerAccountName</account-name>|; s|<account-access-key></account-access-key>|<account-access-key>$ControllerAccessKey</account-access-key>|; s|</controller-info>|<controller-keystore-filename>cacerts.jks</controller-keystore-filename><controller-keystore-password>$MachineAgentControllerKeystorePass</controller-keystore-password></controller-info>|" $MachineAgentControllerXML 
    fi
    
    # Copy keystore
    echo $(date '+%H:%M:%S')" - Copying keystore."
    MachineAgentControllerKeystore=$(echo $MachineAgentConfDir"cacerts.jks")
    cp conf/cacerts.jks $MachineAgentControllerKeystore
    if [[ ! -e $MachineAgentControllerKeystore ]]; then
        echo $(date '+%H:%M:%S')" - Not found: $MachineAgentControllerKeystore."
        exit
    else
        echo $(date '+%H:%M:%S')" - Found: $MachineAgentControllerKeystore."
    fi

    # Configure Machine Agent service and proxy settings
    echo $(date '+%H:%M:%S')" - Preparing service configuration file."
    MachineAgentSourceServiceFile=$(echo $MachineAgentInstallDir"etc/systemd/system/appdynamics-machine-agent.service")
    MachineAgentJreDir=$(echo $MachineAgentInstallDir"jre/")
    if [[ ! -e $MachineAgentSourceServiceFile ]]; then
        echo $(date '+%H:%M:%S')" - Not found: $MachineAgentSourceServiceFile."
        exit
    else
        echo $(date '+%H:%M:%S')" - Found: $MachineAgentSourceServiceFile."
    fi
    cp $MachineAgentSourceServiceFile $MachineAgentSourceServiceFile"2"
    if [[ $proxyEnabled = "true" ]]; then
        sed -i "s|^Environment=MACHINE_AGENT_USER=.*|Environment=MACHINE_AGENT_USER=$MachineAgentUser|; s|^Environment=MACHINE_AGENT_HOME=.*|Environment=MACHINE_AGENT_HOME=$MachineAgentInstallDir|; s|^Environment=JAVA_HOME=.*|Environment=JAVA_HOME=$MachineAgentJreDir|; s|^User=.*|User=$MachineAgentUser|; s|\#Environment=\"JAVA_OPTS=-D<sys-property1>=<value1> -D<sys-property2>=<value2>\"|Environment=\"JAVA_OPTS=-Dappdynamics.http.proxyHost=$proxyHost -Dappdynamics.http.proxyPort=$proxyPort\"|" $MachineAgentSourceServiceFile"2"
    elif [[ $proxyEnabled = "false" ]]; then
        sed -i "s|^Environment=MACHINE_AGENT_USER=.*|Environment=MACHINE_AGENT_USER=$MachineAgentUser|; s|^Environment=MACHINE_AGENT_HOME=.*|Environment=MACHINE_AGENT_HOME=$MachineAgentInstallDir|; s|^Environment=JAVA_HOME=.*|Environment=JAVA_HOME=$MachineAgentJreDir|; s|^User=.*|User=$MachineAgentUser|" $MachineAgentSourceServiceFile"2"     
    fi
    
    if [[ $haswrite == "yes" ]] && [[ $hasExecute == "yes" ]]; then
        echo $(date '+%H:%M:%S')" - Deploying Machine Agent service."
        mv $MachineAgentSourceServiceFile"2" /etc/systemd/system/appdynamics-machine-agent.service
        systemctl enable appdynamics-machine-agent
        systemctl start appdynamics-machine-agent
        echo $(date '+%H:%M:%S')" - Checking service state."
        MachineAgentServiceState=$(systemctl is-active appdynamics-machine-agent)
        echo $(date '+%H:%M:%S')" - appdynamics-machine-agent service is $MachineAgentServiceState."
        if [ $MachineAgentServiceState = "active" ]; then
            echo $(date '+%H:%M:%S')" - Check succeeded."
        else
            echo $(date '+%H:%M:%S')" - Could not verify service state."
            exit
        fi
        echo $(date '+%H:%M:%S')" - Machine Agent has been deployed and is up and running."
        echo $(date '+%H:%M:%S')" - Use 'systemctl status/stop/start/restart appdynamics-machine-agent' for service operations."
    elif [[ $haswrite == "yes" ]] && [[ $hasExecute == "no" ]]; then
        echo $(date '+%H:%M:%S')" - Deploying Machine Agent service."
        mv $MachineAgentSourceServiceFile"2" /etc/systemd/system/appdynamics-machine-agent.service
        systemctl enable appdynamics-machine-agent
        echo $(date '+%H:%M:%S')" - Machine Agent has been deployed but not started."
        echo $(date '+%H:%M:%S')" - Fix permissions on install folder (e.g. 755) and start the agent."
        echo "chmod -R 755 $MachineAgentInstallDir"
    elif [[ $haswrite == "no" ]] && [[ $hasExecute == "yes" ]]; then
        echo $(date '+%H:%M:%S')" - Insufficient privileges to create system service."
        echo $(date '+%H:%M:%S')" - To finish setup run the below commands with an elevated user."
        echo "mv $MachineAgentSourceServiceFile"2" /etc/systemd/system/appdynamics-machine-agent.service"
        echo "systemctl enable appdynamics-machine-agent"
        echo "systemctl start appdynamics-machine-agent"
    elif [[ $haswrite == "no" ]] && [[ $hasExecute == "no" ]]; then
        echo $(date '+%H:%M:%S')" - Insufficient privileges to create system service."
        echo $(date '+%H:%M:%S')" - To finish setup run the below commands with an elevated user."
        echo "mv $MachineAgentSourceServiceFile"2" /etc/systemd/system/appdynamics-machine-agent.service"
        echo "systemctl enable appdynamics-machine-agent"
        echo "systemctl start appdynamics-machine-agent"
        echo $(date '+%H:%M:%S')" - Also fix permissions on install folder (e.g. 755) and start the agent."
        echo "chmod -R 755 $MachineAgentInstallDir"
    fi
}
function verifyReqsMA {

    # Check if root
    MachineAgentUser=$(whoami)
    echo $(date '+%H:%M:%S')" - Running as user $MachineAgentUser."

    if [[ $MachineAgentUser == "root" ]]; then
        echo $(date '+%H:%M:%S')" - Using root, setup is going to quit."
        exit
    fi

    # Check write permissions for service creation
    echo $(date '+%H:%M:%S')" - Check if user can create a service."
    if [ -w /etc/systemd/system ]; then
        echo $(date '+%H:%M:%S')" - OK."
        haswrite="yes"
    else
        haswrite="no"
        echo $(date '+%H:%M:%S')" - This user cannot create system services."
        echo $(date '+%H:%M:%S')" - Follow instructions in the end to finish setup."
    fi

    # Confirm if commands are executable
    echo $(date '+%H:%M:%S')" - Checking packages."
    canRun+=($(test -x $(command -v ip) && echo "ip:yes" || echo "ip:no"))
    canRun+=($(test -x $(command -v df) && echo "df:yes" || echo "df:no"))
    canRun+=($(test -x $(command -v awk) && echo "awk:yes" || echo "awk:no"))
    canRun+=($(test -x $(command -v basename) && echo "basename:yes" || echo "basename:no"))
    canRun+=($(test -x $(command -v cat) && echo "cat:yes" || echo "cat:no"))
    canRun+=($(test -x $(command -v date) && echo "date:yes" || echo "date:no"))
    canRun+=($(test -x $(command -v dmesg) && echo "dmesg:yes" || echo "dmesg:no"))
    canRun+=($(test -x $(command -v md5sum) && echo "md5sum:yes" || echo "md5sum:no"))
    canRun+=($(test -x $(command -v readlink) && echo "readlink:yes" || echo "readlink:no"))
    canRun+=($(test -x $(command -v sed) && echo "sed:yes" || echo "sed:no"))
    canRun+=($(test -x $(command -v uname) && echo "uname:yes" || echo "uname:no"))
    canRun+=($(test -x $(command -v ps) && echo "ps:yes" || echo "ps:no"))
    canRun+=($(test -x $(command -v unzip) && echo "unzip:yes" || echo "unzip:no"))
    canRun+=($(test -x $(command -v whoami) && echo "whoami:yes" || echo "whoami:no"))
    canRun+=($(test -x $(command -v systemctl) && echo "systemctl:yes" || echo "systemctl:no"))

    count=0
    for command in ${canRun[@]}
    do
        if [[ $command =~ "no" ]]; then
            echo $(date '+%H:%M:%S')" - $command."
            count+=1
        fi
    done

    if [[ $count > 0 ]]; then
        echo $(date '+%H:%M:%S')" - $count packages failed permission check for user $MachineAgentUser."
        echo $(date '+%H:%M:%S')" - Make sure that user can execute those commands and try again."
        exit
    else
        echo $(date '+%H:%M:%S')" - Prerequisites check passed."
    fi

}
function verifyOSUser {
    
    # Compare script user with binaries and destination dir
    scriptUser=$(whoami)
    packageUser=$(ls -ld $1 | awk '{print $3}')
    dstDirUser=$(ls -ld $2 | awk '{print $3}')
    if [ "$scriptUser" == "$packageUser" ] && [ "$dstDirUser" == "$packageUser" ]; then
    	echo $(date '+%H:%M:%S')" - Files/dirs ownership verified."
    else
	echo $(date '+%H:%M:%S')" - Failed to verify user (owner)."
	echo $(date '+%H:%M:%S')" - script owner: $scriptUser, package owner: $packageUser, destination owner: $dstDirUser."
	echo ""
	exit
    fi

}

if [[ $# -eq 0 ]]; then
    echo "Type 'deployAgent.sh help' for list of commands."
    exit
elif [[ $1 == "help" && $# -eq 1 ]]; then
    echo ""
    echo "Usage: {type} {item}"
    echo "       {type}: install | instrument | healthcheck"
    echo "       {item}: -ja | -ma | -prod | -nonprod"
    echo ""
    echo "Available options (current release):"
    echo "       './deployAgent.sh install -ja' installs a Java Agent."
    echo "       './deployAgent.sh install -ma' installs a Machine Agent."
    echo "       './deployAgent.sh instrument -ja' instruments an additional JVM."
    echo "       './deployAgent.sh healthcheck -prod' check connectivity for prod."
    echo "       './deployAgent.sh healthcheck -nonprod' for nonprod."
    echo ""
    exit
elif [[ $1 == "install" && $2 == "-ja" && $# -eq 2 ]]; then
    getConfigProperties
    setHomeDir
    setSAASController
    getSAASController
    setAppName
    setAppTierName
    setAppNodeName
    setJavaType
    setJavaApplication

    # Validate installation dir and create if needed
    JavaAgentInstallDir=$home"/JavaAgent"
    echo $(date '+%H:%M:%S')" - Checking destination dir and package."
    if [[ ! -d $JavaAgentInstallDir ]]; then
        mkdir -p $JavaAgentInstallDir &>/dev/null
    fi
    # Verify owner
    if [[ -d $JavaAgentInstallDir ]]; then
        verifyOSUser "$JavaAgentSourceDir" "$JavaAgentInstallDir"
    else
        echo $(date '+%H:%M:%S')" - Could not create $JavaAgentInstallDir."
        exit
    fi
    # Confirm installation dir is empty
    numOfFiles=$(ls $JavaAgentInstallDir | wc -l)
    if [[ $numOfFiles -eq 0 ]]; then
        echo $(date '+%H:%M:%S')" - Using $JavaAgentInstallDir."
    else
        echo $(date '+%H:%M:%S')" - $JavaAgentInstallDir not empty."
        echo $(date '+%H:%M:%S')" - This script uses $JavaAgentInstallDir."
        exit
    fi
    # Copy contents from source
    echo $(date '+%H:%M:%S')" - Copying Java Agent."
    cp -r $JavaAgentSourceDir/* $JavaAgentInstallDir
    # Verify installation dir and copy keystore. Update controller-info.xml
    JavaAgentVerDir=$(ls $JavaAgentInstallDir | grep -e ver)
    JavaAgentConfDir=$(echo $JavaAgentInstallDir/$JavaAgentVerDir/conf)
    JavaAgentControllerXML=$(echo $JavaAgentConfDir/controller-info.xml)
    JavaAgentControllerKeystore=$(echo $JavaAgentConfDir/cacerts.jks)
    cp conf/cacerts.jks $JavaAgentControllerKeystore
    if [[ ! -e $JavaAgentControllerKeystore ]]; then
        echo $(date '+%H:%M:%S')" - Not found: $JavaAgentControllerKeystore."
        exit
    else
        echo $(date '+%H:%M:%S')" - Found: $JavaAgentControllerKeystore."
        JavaAgentControllerKeystorePass="changeit"
        echo $(date '+%H:%M:%S')" - Updating $JavaAgentControllerXML."
        sed -i "s|<controller-host.*controller-host>|<controller-host>$ControllerHost</controller-host>|; s|<controller-port.*controller-port>|<controller-port>443</controller-port>|; s|<controller-ssl-enabled.*controller-ssl-enabled>|<controller-ssl-enabled>true</controller-ssl-enabled>|; s|<use-encrypted-credentials.*use-encrypted-credentials>|<use-encrypted-credentials>false</use-encrypted-credentials>|; s|<account-name.*account-name>|<account-name>$ControllerAccountName</account-name>|; s|<account-access-key.*account-access-key>|<account-access-key>$ControllerAccessKey</account-access-key>|; s|</controller-info>|<controller-keystore-filename>$JavaAgentControllerKeystore</controller-keystore-filename><controller-keystore-password>$JavaAgentControllerKeystorePass</controller-keystore-password></controller-info>|" $JavaAgentControllerXML
    fi
    # Instrument java application
    instrJavaApplication
elif [[ $1 == "install" && $2 == "-ma" && $# -eq 2 ]]; then
    verifyReqsMA
    getConfigProperties
    setHomeDir
    setSAASController
    getSAASController
    setMachineAgent
    setAppName
    if [ $MachineAgentOnly = "true" ]; then
        setAppTierName
        setAppNodeName
    elif [ $MachineAgentOnly = "false" ]; then
        echo ""
        echo $(date '+%H:%M:%S')" - Skipping application/tier/node definition in controller-info.xml."
    fi
    installMA

elif [[ $1 == "instrument" && $2 == "-ja" && $# -eq 2 ]]; then
    getConfigProperties
    JavaAgentInstallDir="/opt/appdynamics/JavaAgent"
    echo ""
    if [[ ! -d $JavaAgentInstallDir ]]; then
        echo $(date '+%H:%M:%S')" - JavaAgent dir not found."
        exit
    else
        echo $(date '+%H:%M:%S')" - JavaAgent dir found."
        JavaAgentVerDir=$(ls $JavaAgentInstallDir | grep -e ver)
        JavaAgentConfDir=$(echo $JavaAgentInstallDir/$JavaAgentVerDir/conf)
        JavaAgentControllerXML=$(echo $JavaAgentConfDir/controller-info.xml)
    fi
    if [[ ! -s $JavaAgentControllerXML ]]; then
        echo $(date '+%H:%M:%S')" - Couldn't find controller-info.xml."
        exit
    else
        echo $(date '+%H:%M:%S')" - controller-info.xml found and is of non-zero size."
    fi
    setAppTierName
    setAppNodeName
    setJavaType
    setJavaApplication
    instrJavaApplication
    exit
elif [[ $1 == "healthcheck" && $2 == "-prod" && $# -eq 2 ]]; then
    
    getConfigProperties
    
    ControllerHost=$controllerHostProd
    ControllerAccountName=$controllerAccountProd
    ControllerProtocol=$controllerProtocolProd
    ControllerPort=$controllerPortProd
    ControllerAccountName=$controllerAccountProd
    ControllerAccessKey=$controllerAccessKeyProd
    ControllerAccessToken=$ApiTokProd
    
    setHomeDir
    getSAASController

elif [[ $1 == "healthcheck" && $2 == "-nonprod" && $# -eq 2 ]]; then
    
    getConfigProperties
    
    ControllerHost=$controllerHostNonprod
    ControllerAccountName=$controllerAccountNonprod
    ControllerProtocol=$controllerProtocolNonprod
    ControllerPort=$controllerPortNonprod
    ControllerAccountName=$controllerAccountNonprod
    ControllerAccessKey=$controllerAccessKeyNonprod
    ControllerAccessToken=$ApiTokNonprod
    
    setHomeDir
    getSAASController

fi
