###################################
## AppDynamics Deploy Agent Tool ##
###################################

1. Overview
	deployAgent is a script procedure written to help automate installation and configuration of AppDynamics agents.
	The script, when ran, guides the user through a series of steps to help prepare for install and then deploys the selected agent.
	Furthermore it will instrument the agent and the target customer application, based on input parameters.
	The tool is also capable of fully automating the whole process for Windows. A full list of available functions is described below (or via 'cscript deployAgent.vbs help' or  './deployAgent.sh help')

2. Capabilities
	Current version (Windows) can:
	- Install Dot Net Agent and instrument IIS and Standalone Dot Net applications.
	- Install Java Agent and instrument JBOSS/Tomcat/WebSphereAS applications.
		- Tested with JBoss 5 and JBoss 6
		- Tested with Tomcat 6, Tomcat 7, Tomcat 8, Tomcat 8.5 and Tomcat 9
		- Tested with WebSphere Application Server 8.5
	- Install Machine Agent and prepare it for work. Auto-detect configuration in case of existing Dot Net Agent.
	- Uninstall Dot Net Agent. No backup made i.e. existing configuration is cleaned.
	- Uninstall Machine Agent. Backup made of existing Machine Agent installation folder (in the same parent dir).
	- Uninstall Java Agent. Backup made of existing Java Agent installation folder (in deployAgent backup folder).
	- Instrument additional Java application (since sometimes we have more than one application/server) considering 'install' option has been already invoked/completed.
	- Upgrade Dot Net Agent.
	- Upgrade Machine Agent.
	- Upgrade Java Agent.
	- The above was tested on Windows Server 2003 R2, Windows Server 2008 R2 and Windows Server 2012 R2
	- Windows Server 2003 is no longer supported for Machine Agent
	
	Current version (Linux) can:
	- Install Java Agent and instrument JBOSS/Tomcat/WebSphereAS applications.
	- Instrument additional Java application (since sometimes we have more than one application/server) considering 'install' option has been already invoked/completed.
	- Install Machine Agent and prepare it for work.
	- The above was tested on CentOS 7 but also works on RHEL. AIX is not supported.
 
3. Instructions
	[Windows Server]
	Preprequisites:
	- For Dot Net Agent ensure that at least NET Framework 2 (or newer) is installed.
	- deployAgent can detect if certain critical KB updates are missing. Installations will be terminated if that is the case, in order to protect system/agent from harm.
		- KB2999226 (Windows Server 2008/2012) https://support.microsoft.com/en-us/help/2999226/
		- KB948963 (Windows Server 2003) https://support.microsoft.com/en-us/help/948963/an-update-is-available-to-add-support-for-the-tls-rsa-with-aes-128-cbc
	- Account must be Administrator on server
	Instructions:
	- Place deployAgent folder in D:\AppDynamics\ (C:\AppDynamics if D: does not exist)
	- Open CMD with Administrator rights (right-click "Run as administrator")
	- CD to <drive>:\AppDynamics\deployAgent\
	- Run "cscript deployAgent.vbs help" for command options and examples
	
	[Linux Server]
	Prerequisites:
	- Account must be root or part of sudo-ers list. This is especially critical for Machine Agent deployment.
	- User is set to use Bash (/usr/bin/bash)
	Instructions:
	- Place deployAgent folder in /tmp/ (it's ok to copy to another dir but path should contain no spaces)
	- CD to /tmp/deployAgent/
	- Provide permissions to script (chmod 755 deployAgent.sh)
	- Run "./deployAgent.sh help" for command options and examples. Always run deployAgent.sh from its directory.
 
4. Directory Structure
	- [deployAgent] Main folder that holds all files.
		|- [backup] Directory where procedure will place backup of elements (files, registry etc) before they are modified.
			|- [DotNetAgent] Where backup files from Dot Net Agent installation are placed.
			|- [JavaAgent] Where backup files from Java Agent installation are placed.
			|- [MachineAgent] Where backup files from Machine Agent installation are placed.
		|- [binaries] Directory containing all installation files for agents.
			|- [DotNetInstall] Directory where Dot Net Agent binaries are placed.
			|- [JavaInstall] Directory where Java Agent binaries are placed.
			|- [MachineInstall] Directory where Machine Agent binaries are placed.
			|- [DotNetUpgrade] Directory where Dot Net Agent upgrade binaries are placed.
			|- [JavaUpgrade] Directory where Java Agent upgrade binaries are placed.
			|- [MachineUpgrade] Directory where Java Agent upgrade binaries are placed.
		|- [conf] Configuration directory of deployAgent.
			|- [dotnet] Directory containing config.xml templates used for install.
			|- [*.pem] AppDynamics certificate files needed by agents. We use cacerts.jks the *.cer are left in conf folder in case someone needs one of them.
			|- [cacerts.jks] Java keystore containing the certificate files needed by Machine Agent and Java Agent. This is used by deployAgent.
			|- [autodeploy_template.xml] The template you can use to create your autodeploy.xml. "autodeploy.xml" is then used by autodeploy option of deployAgent.
			|- [properties.xml] deployAgent configuration needed for proper deployment of agents. They can be adjusted if needed (when it makes sense).
		|- [deployAgent.sh] Bash version of deployAgent (for Linux)
		|- [deployAgent.vbs] VBScript version of deployAgent (for Windows)
		|- [docs] Latest documentation for using deployAgent.
		|- [ReadMe.txt] This file. A mandatory file to read before using the deployAgent.
		|- [tmp] Directory used for temporary storage of files during the various operations.